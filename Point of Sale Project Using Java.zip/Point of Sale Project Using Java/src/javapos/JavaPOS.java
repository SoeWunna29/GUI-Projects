
package javapos;

public class JavaPOS {

    public static void main(String[] args) {
        MainWindow.main(null);
    }
    
}
